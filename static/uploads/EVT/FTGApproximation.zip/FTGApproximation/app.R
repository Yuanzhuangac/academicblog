library(shiny)
library(QRM)
library(brms)
# Define UI for app that draws a histogram ----
ui <- fluidPage(
  # App title ----
  titlePanel("Sample Maxima Approximation Using Extreme Value Distributions"),
  # Sidebar layout with input and output definitions ----
  sidebarLayout(
    # Sidebar panel for inputs ----
    sidebarPanel(
      # Input: Numbers ----
      sliderInput("n1", "Number of iid Exponential Rvs:",
                  min = 1, max = 30,
                  value = 1, step = 1),
      sliderInput("n2", "Number of iid Cauchy Rvs:",
                  min = 1, max = 20,
                  value = 1, step = 1),
      sliderInput("n3", "Number of iid Normal Rvs:",
                  min = 1, max = 10000,
                  value = 1, step = 1)
    ),
    # Main panel for displaying outputs ----
    mainPanel(
      # Output: DF ----
      plotOutput(outputId = "distPlotexp"),
      plotOutput(outputId = "distPlotcauchy"),
      plotOutput(outputId = "distPlotnormal"),
      # Output: Reference ----
      textOutput(outputId = "reference")
    ),
    position = c("right")
  )
)

# Define server logic required to draw a histogram ----
server <- function(input, output) {
  output$distPlotexp <- renderPlot({
    x <- seq(from = -2, to = 6, length.out = 20000)
    df_gumbel <- pGumbel(x, mu = 0, sigma = 1)
    exp_n <- pexp(x+log(input$n1))^(input$n1)
    plot(x, df_gumbel, col = "blue",xlab = "x",ylab ="DF",lwd = 0.5, cex = 0.25, ylim = c(0,1))
    lines(x, exp_n, col = "red")
    legend("topright",pch=c(15,15),legend=c("Gumbel","N iid Exponential RVs"),col=c("blue","red"),bty="n")
    title(main = "Using Gumbel to fit maxima of N iid Exponential Rvs")
  })
  output$distPlotcauchy <- renderPlot({
    x <- seq(from = -2, to = 6, length.out = 20000)
    df_frechet <- pfrechet(x, loc = 0, scale = 1, shape = 1)
    cauchy_n <- pcauchy(x*input$n2/pi)^input$n2
    plot(x, df_frechet, col = "blue",xlab = "x",ylab ="DF",lwd = 0.5, cex = 0.25, ylim = c(0,1))
    lines(x, cauchy_n, col = "red")
    legend("topright",pch=c(15,15),legend=c("Fréchet","N iid Cauchy RVs"),col=c("blue","red"),bty="n")
    title(main = "Using Fréchet to fit maxima of N iid Cauchy Rvs")
  })
  output$distPlotnormal <- renderPlot({
    x <- seq(from = -2, to = 6, length.out = 20000)
    df_gumbel <- pGumbel(x, mu = 0, sigma = 1)
    trans <- function(x,n){
      y <- x/(sqrt(2*log(n))) + sqrt(2*log(n)) - (log(log(n))+log(4*pi))/(2*sqrt(2*log(n)))
      return(y)
    }
    normal_n <- pnorm(trans(x,input$n3))^input$n3
    plot(x, df_gumbel, col = "blue",xlab = "x",ylab ="DF",lwd = 0.5, cex = 0.25, ylim = c(0,1))
    lines(x, normal_n, col = "red")
    legend("topright",pch=c(15,15),legend=c("Gumbel","N iid Normal RVs"),col=c("blue","red"),bty="n")
    title(main = "Using Gumbel to fit maxima of N iid Normal Rvs")
  })
  output$reference <- renderText("Reference：Embrechts P., Klüppelberg C., Mikosch T. Modelling Extremal Events[M]. Berlin, Heidelberg: Springer Berlin Heidelberg, 1997.")
}

# Create Shiny app ----
shinyApp(ui = ui, server = server)