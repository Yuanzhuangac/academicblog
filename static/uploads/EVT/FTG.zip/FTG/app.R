library(shiny)
library(QRM)
# Define UI for app that draws a histogram ----
ui <- fluidPage(
  # App title ----
  titlePanel("Fisher-Tippet-Gnedenko Visualization"),
  # Sidebar layout with input and output definitions ----
  sidebarLayout(
    # Sidebar panel for inputs ----
    sidebarPanel(
      # Input: Parameter for GEV ----
      sliderInput("a", "Shape Parameter: α",
                  min = 1, max = 4,
                  value = 2, step = 0.1),
      sliderInput("b", "Scale Parameter: β",
                  min = 0.5, max = 4,
                  value = 1, step = 0.1)
    ),
    # Main panel for displaying outputs ----
    mainPanel(
      # Output: Density ----
      plotOutput(outputId = "distPlot"),
      # Output: Reference ----
      textOutput(outputId = "reference"),
      textOutput(outputId = "notice")
    ),
    position = c("right")
  )
)

# Define server logic required to draw a histogram ----
server <- function(input, output) {
  output$distPlot <- renderPlot({
    x <- seq(from = -2, to = 6, length.out = 10000)
    dens_gumbel <- dGEV(x, xi = 0, mu = input$a, sigma = input$b)
    dens_weibull<- dGEV(x, xi = -1/input$a, mu = -1*input$b, sigma = input$b/input$a)
    dens_frechet <- dGEV(x, xi = 1/input$a, mu = 1*input$b, sigma = input$b/input$a)
    plot(x, dens_gumbel, col = "blue",xlab = "x",ylab ="Density",lwd = 0.5, cex = 0.1, xlim = c(-2,6), ylim = c(0,1))
    lines(x, dens_weibull, col = "red")
    lines(x, dens_frechet, col = "green")
    legend("topright",pch=c(15,15),legend=c("Weibull","Gumbel","Fréchet"),col=c("red","blue","green"),bty="n")
  })
  output$reference <- renderText("Reference：Embrechts P., Klüppelberg C., Mikosch T. Modelling Extremal Events[M]. Berlin, Heidelberg: Springer Berlin Heidelberg, 1997.")
  output$notice <- renderText("Notice: The Parametrization may be different.")
}

# Create Shiny app ----
shinyApp(ui = ui, server = server)