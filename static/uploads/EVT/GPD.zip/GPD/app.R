library(shiny)
library(QRM)
library(brms)
# Define UI for app that draws a histogram ----
ui <- fluidPage(
  # App title ----
  titlePanel("Generalised Pareto Distribution (GPD)"),
  # Sidebar layout with input and output definitions ----
  sidebarLayout(
    # Sidebar panel for inputs ----
    sidebarPanel(
      # Input: Numbers ----
      sliderInput("xi", "ξ",
                  min = -2.5, max = 2.5,
                  value = 1, step = 0.1)
    ),
    # Main panel for displaying outputs ----
    mainPanel(
      # Output: DF ----
      plotOutput(outputId = "distPlot"),
      # Output: Reference ----
      textOutput(outputId = "reference")
    ),
    position = c("right")
  )
)

# Define server logic required to draw a density plot ----
server <- function(input, output) {
  output$distPlot <- renderPlot({
    x <- seq(from = 0.0001, to = 2, length.out = 10000)
    GPD_xi <- dGPD(x, xi = input$xi, beta = 1)
    plot(x, GPD_xi, col = "blue",xlab = "x",ylab ="Density",lwd = 0.5, cex = 0.2,xlim = c(0,2), ylim = c(0,4))
    lines(x, GPD_xi, col = "blue", lwd = 2.5)
    title(main = "GPD Density with β=1")
  })
  output$reference <- renderText("Reference：Embrechts P., Klüppelberg C., Mikosch T. Modelling Extremal Events[M]. Berlin, Heidelberg: Springer Berlin Heidelberg, 1997.")
}

# Create Shiny app ----
shinyApp(ui = ui, server = server)