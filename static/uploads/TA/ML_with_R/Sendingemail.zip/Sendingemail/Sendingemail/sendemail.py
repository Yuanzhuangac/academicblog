import smtplib
from email.mime.text import MIMEText
from email.utils import formataddr
from email.mime.multipart import MIMEMultipart
from email.header import Header
import pandas as pd
import smtplib    

# 设置第三方 SMTP 服务
mail_host = "smtp.163.com"  # 设置服务器
mail_user = "nkmlwithr@163.com"  # xxx是你的163邮箱用户名，此处为助教邮箱
mail_pass = "GGBCWDXSTUUGWQWG"  # 口令是你设置的163授权密码 
sender = 'nkmlwithr@163.com'    # 设置发送者邮箱，此处为助教邮箱

data = pd.read_csv("D:\Sendingemail\Grades2.csv") # 记得修改登分表格这个csv所在的位置
print(data)
receivers = list(data['Mail'])  # 谁来接受这封邮件，这里指学生们

for i in range(data.shape[0]):
    msg=MIMEMultipart()#创建一个可以同时添加正文和附件的msg
# 设置HTML格式的邮件正文
# 三个单引号表示包围注释内容，用来包含HTML代码
    mail_msg_basic='''
    <p>同学好，所有作业已经批改完，请查收你的作业成绩：</p>
    <p><b><b>姓名：</b>{0} &nbsp; <b>学号：</b>{1}</p>
    <table border="1">
    <tr>
        <th>作业序号</th>
        <th>得分</th>
    </tr>
    <tr>
        <td>1</td>
        <td>{2}</td>
    </tr>
    <tr>
        <td>2</td>
        <td>{3}</td>
    </tr>
    <tr>
        <td>3</td>
        <td>{4}</td>
    </tr>
    <tr>
        <td>4</td>
        <td>{5}</td>
    </tr>
    <tr>
        <td>5</td>
        <td>{6}</td>
    </tr>
    <tr>
        <td>6</td>
        <td>{7}</td>
    </tr>
    <tr>
        <td>7</td>
        <td>{8}</td>
    </tr>
    <tr>
        <td>8</td>
        <td>{9}</td>
    </tr>
    <tr>
        <td>9</td>
        <td>{10}</td>
    </tr>
    <tr>
        <td>10</td>
        <td>{11}</td>
    </tr>
    <tr>
        <td>11</td>
        <td>{12}</td>
    </tr>
    <tr>
        <td>12</td>
        <td>{13}</td>
    </tr>
    </table>
    <p>经张老师和我的讨论，我将同学们成绩最高的8次作业计入平时分，你们无需担心偶尔的失手对成绩造成毁灭性结果。</p>
    <p>附件中是我对全班同学历次作业的批改记录和整体评价，大家可以参考。期末大作业在6月30日截止，请大家注意Deadline。</p>
    <p>最后的最后，请同学们动动手指，帮我填一下这个<a href="https://nkujwc.wjx.cn/vm/OB3mcYP.aspx">助教评价问卷</a>（教务通知我说，6月24日晚12点截止），这对我来说很重要！</p>
    <p>祝愿同学们学业进步！(´▽`)ﾉ</p> 
    <p style="text-align:right">《机器学习与R》助教 &nbsp; 庄源</p>
    '''.format(data.iloc[i,0],data.iloc[i,1],data.iloc[i,3],data.iloc[i,4],data.iloc[i,5],data.iloc[i,6],data.iloc[i,7],data.iloc[i,8],data.iloc[i,9],data.iloc[i,10],data.iloc[i,11],data.iloc[i,12],data.iloc[i,13],data.iloc[i,14])
# 添加正文
    msg.attach(MIMEText(mail_msg_basic,'html','utf-8'))
# 添加附件
    att1=MIMEText(open('D:\Sendingemail\Suggestions_on_Homework.pdf','rb').read(),'base64','utf-8') # 添加附件，没附件可以注释掉这行和下面三行
    att1["Content-Type"]='application/octet-stream' #数据传输类型的定义
    att1["Content-Disposition"]='attachment;filename="Suggestions_on_Homework.pdf"'#定义文件在邮件中显示的文件名和后缀名，名字不可为中文
    msg.attach(att1)# 将附件添加到邮件内容当中
    msg['From'] = formataddr(["《机器学习与R》助教 庄源",sender]) 
    msg['To'] = formataddr([data.iloc[i,0],receivers[i]]) # 接受者显示
    subject = '机器学习与R 作业成绩汇总与作业点评' #邮件标题
    msg['Subject'] = Header(subject, 'utf-8')
    try:
        print("现在正在发送{0}的邮件".format(data.iloc[i,0]))
        smtpObj = smtplib.SMTP_SSL(mail_host, 465)
        print("已建立SSL连接")
        smtpObj.helo(mail_host)
        smtpObj.ehlo(mail_host)
        print("成功与服务器取得联系")
        smtpObj.login(mail_user, mail_pass)
        print("成功登陆")
        receiver = [1]
        receiver[0] = receivers[i]
        print(receiver)
        smtpObj.send_message(msg, sender, receiver)
        print("{0}邮件发送成功".format(data.iloc[i,0]))
    except smtplib.SMTPException:
        print("Error: 无法发送{}的邮件".format(data.iloc[i,0]))